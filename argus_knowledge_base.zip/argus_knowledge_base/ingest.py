#!/usr/bin/env python3
# ingest.py — Argus RAG Pipeline
# Loads pre-fetched JSON data into ChromaDB
#
# Usage:
#   python ingest.py              # ingest all sources
#   python ingest.py --sources owasp attack
#   python ingest.py --sources nvd hackerone
#
# To refresh live data first:
#   python scripts/fetch_nvd.py
#   python scripts/fetch_hackerone.py
#   python ingest.py

import json
import time
import hashlib
import argparse
from pathlib import Path

# ── ChromaDB setup ────────────────────────────────────────
import chromadb
from chromadb.utils import embedding_functions

CHROMA_DIR        = "./argus_chroma_db"
CHROMA_COLLECTION = "argus_knowledge_base"
EMBED_MODEL       = "all-MiniLM-L6-v2"
DATA_DIR          = Path(__file__).parent / "data"


def _get_collection():
    client = chromadb.PersistentClient(path=CHROMA_DIR)
    ef = embedding_functions.SentenceTransformerEmbeddingFunction(model_name=EMBED_MODEL)
    return client.get_or_create_collection(
        name=CHROMA_COLLECTION,
        embedding_function=ef,
        metadata={"hnsw:space": "cosine"},
    )


def _doc_id(source: str, key: str) -> str:
    return hashlib.md5(f"{source}::{key}".encode()).hexdigest()


def _load_json(path: Path) -> list | dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ── OWASP ─────────────────────────────────────────────────
def ingest_owasp():
    col = _get_collection()
    data = _load_json(DATA_DIR / "owasp" / "owasp_top10_2021.json")
    docs, ids, metas = [], [], []

    for entry in data:
        payloads_text = "\n".join(entry.get("payloads", [])[:10])
        text = (
            f"OWASP {entry['id']}: {entry['name']}\n"
            f"CWEs: {', '.join(entry.get('cwe_ids', []))}\n"
            f"Description: {entry['description']}\n"
            f"Example Payloads:\n{payloads_text}"
        )
        docs.append(text)
        ids.append(_doc_id("OWASP", entry["id"]))
        metas.append({
            "source": "OWASP Top 10 2021",
            "owasp_id": entry["id"],
            "owasp_name": entry["name"],
            "url": entry.get("url", ""),
        })

    col.upsert(documents=docs, ids=ids, metadatas=metas)
    return len(docs)


# ── MITRE ATT&CK ──────────────────────────────────────────
def ingest_attack():
    col = _get_collection()
    data = _load_json(DATA_DIR / "mitre_attack" / "techniques.json")
    docs, ids, metas = [], [], []

    for t in data:
        text = (
            f"ATT&CK Technique: {t['id']} — {t['name']}\n"
            f"Tactic: {t.get('tactic','')}\n"
            f"Platforms: {', '.join(t.get('platforms', []))}\n"
            f"Description: {t['description']}\n"
            f"Detection: {t.get('detection', '')}"
        )
        docs.append(text)
        ids.append(_doc_id("ATTACK", t["id"]))
        metas.append({
            "source": "MITRE ATT&CK",
            "technique_id": t["id"],
            "technique_name": t["name"],
            "tactic": t.get("tactic", ""),
            "url": t.get("url", ""),
        })

    col.upsert(documents=docs, ids=ids, metadatas=metas)
    return len(docs)


# ── NVD CVEs ──────────────────────────────────────────────
def ingest_nvd():
    cves_file = DATA_DIR / "nvd" / "cves.json"
    if not cves_file.exists():
        print("  [NVD] ⚠️  No CVE data found. Run: python scripts/fetch_nvd.py")
        return 0

    col = _get_collection()
    data = _load_json(cves_file)
    docs, ids, metas = [], [], []

    for cve in data:
        text = (
            f"CVE ID: {cve['id']}\n"
            f"Severity: {cve['severity']} (CVSS: {cve.get('cvss_score', 'N/A')})\n"
            f"CWEs: {', '.join(cve.get('cwe_ids', []))}\n"
            f"Published: {cve.get('published', '')}\n"
            f"Description: {cve['description']}"
        )
        docs.append(text)
        ids.append(_doc_id("NVD", cve["id"]))
        metas.append({
            "source": "NVD",
            "cve_id": cve["id"],
            "severity": cve.get("severity", "UNKNOWN"),
            "cvss_score": str(cve.get("cvss_score") or ""),
            "published": cve.get("published", ""),
        })

    col.upsert(documents=docs, ids=ids, metadatas=metas)
    return len(docs)


# ── PayloadsAllTheThings ──────────────────────────────────
def ingest_payloads():
    col = _get_collection()
    data = _load_json(DATA_DIR / "payloads" / "payloads_all_the_things.json")
    docs, ids, metas = [], [], []

    for category, col_data in data.items():
        payloads_text = "\n".join(col_data.get("payloads", []))
        text = (
            f"Payload Category: {col_data['category']}\n"
            f"Description: {col_data['description']}\n"
            f"Payloads:\n{payloads_text}"
        )
        docs.append(text)
        ids.append(_doc_id("PATT", category))
        metas.append({
            "source": "PayloadsAllTheThings",
            "category": col_data["category"],
            "payload_count": str(len(col_data.get("payloads", []))),
        })

    col.upsert(documents=docs, ids=ids, metadatas=metas)
    return len(docs)


# ── HackerOne Reports ─────────────────────────────────────
def ingest_hackerone():
    col = _get_collection()
    data = _load_json(DATA_DIR / "hackerone" / "disclosed_reports.json")
    docs, ids, metas = [], [], []

    for r in data:
        text = (
            f"HackerOne Disclosed Report #{r['id']}\n"
            f"Title: {r['title']}\n"
            f"Weakness: {r['weakness_name']} ({r.get('weakness_cwe','')})\n"
            f"Severity: {r['severity']}\n"
            f"Disclosed: {r.get('disclosed_at','')}\n"
            f"URL: {r['url']}\n\n"
            f"--- Vulnerability Information ---\n"
            f"{r['vuln_info']}"
        )
        docs.append(text)
        ids.append(_doc_id("H1", r["id"]))
        metas.append({
            "source": "HackerOne Disclosed Reports",
            "report_id": r["id"],
            "title": r["title"][:200],
            "weakness": r["weakness_name"],
            "cwe": r.get("weakness_cwe", ""),
            "severity": r["severity"],
            "url": r["url"],
        })

    col.upsert(documents=docs, ids=ids, metadatas=metas)
    return len(docs)


# ── Runner ────────────────────────────────────────────────
SOURCES = {
    "owasp":      (ingest_owasp,     "OWASP Top 10 2021"),
    "attack":     (ingest_attack,    "MITRE ATT&CK"),
    "nvd":        (ingest_nvd,       "NVD CVEs"),
    "payloads":   (ingest_payloads,  "PayloadsAllTheThings"),
    "hackerone":  (ingest_hackerone, "HackerOne Disclosed Reports"),
}


def run(sources: list[str]):
    print("\n" + "═" * 55)
    print("   ARGUS — RAG Knowledge Base Ingestion")
    print("═" * 55)

    start = time.time()
    total = 0

    for key in sources:
        fn, label = SOURCES[key]
        print(f"\n[→] {label}")
        count = fn()
        total += count
        print(f"    ✓ {count} documents ingested")

    stats_col = _get_collection()
    elapsed = round(time.time() - start, 1)

    print("\n" + "─" * 55)
    print(f"  ✅ Done in {elapsed}s")
    print(f"  📚 Total documents in DB: {stats_col.count()}")
    print(f"  💾 Persisted: {CHROMA_DIR}")
    print("─" * 55 + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--sources", nargs="+",
        choices=list(SOURCES.keys()),
        default=list(SOURCES.keys()),
    )
    args = parser.parse_args()
    run(args.sources)
