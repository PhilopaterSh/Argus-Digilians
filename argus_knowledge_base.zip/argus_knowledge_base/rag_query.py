#!/usr/bin/env python3
# rag_query.py — Argus RAG Query Interface
# Import this in your LangGraph agent nodes

import hashlib
import chromadb
from chromadb.utils import embedding_functions

CHROMA_DIR        = "./argus_chroma_db"
CHROMA_COLLECTION = "argus_knowledge_base"
EMBED_MODEL       = "all-MiniLM-L6-v2"

_collection = None


def _get_col():
    global _collection
    if _collection is None:
        client = chromadb.PersistentClient(path=CHROMA_DIR)
        ef = embedding_functions.SentenceTransformerEmbeddingFunction(model_name=EMBED_MODEL)
        _collection = client.get_or_create_collection(
            name=CHROMA_COLLECTION,
            embedding_function=ef,
            metadata={"hnsw:space": "cosine"},
        )
    return _collection


def query(text: str, n: int = 5, source: str = None) -> list[dict]:
    """Core semantic search over the Argus knowledge base."""
    col = _get_col()
    where = {"source": source} if source else None
    results = col.query(query_texts=[text], n_results=n, where=where)
    output = []
    if results and results.get("documents"):
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0]
        ):
            output.append({
                "document": doc,
                "metadata": meta,
                "score": round(1 - dist, 4),
            })
    return output


# ── Agent-facing functions ────────────────────────────────

def get_payloads(vuln_type: str, n: int = 5) -> list[str]:
    """
    Get exploit payloads for a vulnerability type.
    Call this in your payload selection agent node.
    Example: get_payloads("SQL Injection")
    """
    results = query(f"{vuln_type} payload exploit", n=n, source="PayloadsAllTheThings")
    payloads = []
    for r in results:
        for line in r["document"].split("\n"):
            s = line.strip()
            if s and not s.startswith(("Payload", "Category", "Description", "Source")):
                payloads.append(s)
    return list(dict.fromkeys(payloads))[:30]  # deduplicated


def get_cves(technology: str, n: int = 5) -> list[dict]:
    """
    Get CVEs related to a technology or vulnerability type.
    Call this in your recon agent node.
    Example: get_cves("Apache Struts")
    """
    results = query(f"{technology} CVE vulnerability", n=n, source="NVD")
    return [{
        "cve_id":    r["metadata"].get("cve_id", ""),
        "severity":  r["metadata"].get("severity", ""),
        "cvss":      r["metadata"].get("cvss_score", ""),
        "summary":   r["document"][:300],
        "score":     r["score"],
    } for r in results]


def get_attack_techniques(scenario: str, n: int = 3) -> list[dict]:
    """
    Get MITRE ATT&CK techniques relevant to an attack scenario.
    Call this in your PoC report generator node.
    Example: get_attack_techniques("web application injection exploit")
    """
    results = query(scenario, n=n, source="MITRE ATT&CK")
    return [{
        "technique_id":   r["metadata"].get("technique_id", ""),
        "technique_name": r["metadata"].get("technique_name", ""),
        "tactic":         r["metadata"].get("tactic", ""),
        "url":            r["metadata"].get("url", ""),
        "score":          r["score"],
    } for r in results]


def get_owasp(finding: str, n: int = 3) -> list[dict]:
    """
    Classify a finding against OWASP Top 10.
    Call this in your vulnerability classification node.
    Example: get_owasp("user input reflected in response without encoding")
    """
    results = query(finding, n=n, source="OWASP Top 10 2021")
    return [{
        "owasp_id":   r["metadata"].get("owasp_id", ""),
        "owasp_name": r["metadata"].get("owasp_name", ""),
        "url":        r["metadata"].get("url", ""),
        "score":      r["score"],
    } for r in results]


def get_real_reports(vuln_type: str, n: int = 5) -> list[dict]:
    """
    Get real HackerOne disclosed reports similar to the finding.
    Call this to enrich PoC reports with real-world context.
    Example: get_real_reports("stored XSS in profile field")
    """
    results = query(f"{vuln_type} bug bounty vulnerability", n=n,
                    source="HackerOne Disclosed Reports")
    return [{
        "title":    r["metadata"].get("title", ""),
        "weakness": r["metadata"].get("weakness", ""),
        "severity": r["metadata"].get("severity", ""),
        "cwe":      r["metadata"].get("cwe", ""),
        "url":      r["metadata"].get("url", ""),
        "summary":  r["document"][:400],
        "score":    r["score"],
    } for r in results]


def full_context(finding: str, n: int = 3) -> dict:
    """
    Master function — returns full enriched context for a finding.
    Use this in your PoC report generator for complete context.

    Returns:
        payloads     → list of exploit strings
        cves         → related CVEs
        attack       → MITRE ATT&CK technique mappings
        owasp        → OWASP Top 10 classification
        real_reports → similar HackerOne reports
    """
    return {
        "payloads":     get_payloads(finding, n),
        "cves":         get_cves(finding, n),
        "attack":       get_attack_techniques(finding, n),
        "owasp":        get_owasp(finding, n),
        "real_reports": get_real_reports(finding, n),
    }


# ── Quick test ────────────────────────────────────────────
if __name__ == "__main__":
    import json
    print("\n[TEST] Querying for: 'SQL injection in login form'\n")
    result = full_context("SQL injection in login form", n=2)
    print(json.dumps(result, indent=2))
