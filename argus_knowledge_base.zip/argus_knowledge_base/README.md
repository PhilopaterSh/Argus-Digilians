# Argus Knowledge Base 🔍
> Pre-fetched security intelligence for the Argus RAG pipeline

---

## What's Inside

| Source | File | Records | What It Contains |
|---|---|---|---|
| OWASP Top 10 2021 | `data/owasp/owasp_top10_2021.json` | 10 | Vulnerability definitions, CWEs, payloads |
| MITRE ATT&CK | `data/mitre_attack/techniques.json` | 10 | Web-relevant techniques, detection guidance |
| NVD CVEs | `data/nvd/cves.json` | ~140 | Real CVEs for XSS, SQLi, SSRF, RCE, etc. |
| PayloadsAllTheThings | `data/payloads/payloads_all_the_things.json` | 10 categories | Exploit payloads for all OWASP vulns |
| HackerOne Reports | `data/hackerone/disclosed_reports.json` | 12+ | Full real-world bug bounty writeups |

---

## Quick Start (Team Members)

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_ORG/argus-knowledge-base.git
cd argus-knowledge-base

# 2. Install dependencies
pip install -r requirements.txt

# 3. Ingest all data into ChromaDB (takes ~2 min first time)
python ingest.py

# 4. Test the RAG
python rag_query.py
```

That's it. No API keys, no internet needed after step 3.

---

## Use in Your Agent

```python
from rag_query import full_context, get_payloads, get_real_reports

# In your LangGraph payload selection node:
payloads = get_payloads("SQL Injection")

# In your PoC report generator node:
context = full_context("reflected XSS in search parameter")
# Returns: payloads, CVEs, ATT&CK techniques, OWASP class, real H1 reports

# To find similar real-world cases:
reports = get_real_reports("SSRF via URL parameter")
```

---

## Refresh Data (Team Lead Only)

Run these scripts to pull the latest data from live sources, then commit:

```bash
# Refresh NVD CVEs (pulls from nvd.nist.gov API)
python scripts/fetch_nvd.py

# Refresh HackerOne reports (tries GraphQL API, falls back to public JSON)
python scripts/fetch_hackerone.py

# Re-ingest into ChromaDB
python ingest.py

# Commit updated data files
git add data/
git commit -m "chore: refresh NVD + HackerOne data"
git push
```

---

## Ingest Specific Sources

```bash
python ingest.py --sources owasp
python ingest.py --sources attack
python ingest.py --sources nvd payloads
python ingest.py --sources hackerone
python ingest.py  # all sources
```

---

## Repo Structure

```
argus-knowledge-base/
│
├── data/                          ← Pre-fetched data (committed to repo)
│   ├── owasp/
│   │   └── owasp_top10_2021.json
│   ├── mitre_attack/
│   │   └── techniques.json
│   ├── nvd/
│   │   └── cves.json
│   ├── payloads/
│   │   └── payloads_all_the_things.json
│   └── hackerone/
│       └── disclosed_reports.json
│
├── scripts/                       ← Run to refresh data from live sources
│   ├── fetch_nvd.py
│   └── fetch_hackerone.py
│
├── ingest.py                      ← Run to populate ChromaDB from data/
├── rag_query.py                   ← Import this in your agent
├── requirements.txt
├── .gitignore                     ← argus_chroma_db/ is excluded
└── README.md
```

> **Note:** `argus_chroma_db/` is in `.gitignore` — each team member generates their own local ChromaDB by running `python ingest.py`

---

## How the RAG Works

```
data/*.json  ──→  ingest.py  ──→  ChromaDB (local)  ──→  rag_query.py  ──→  Argus Agent
  (GitHub)          (run once)     (your machine)         (import this)
```
