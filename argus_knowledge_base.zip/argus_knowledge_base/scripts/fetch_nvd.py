#!/usr/bin/env python3
# scripts/fetch_nvd.py
# Run this script to refresh NVD CVE data
# Usage: python scripts/fetch_nvd.py
# Output: data/nvd/cves.json

import json
import time
import requests
from pathlib import Path

NVD_BASE_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"

KEYWORDS = [
    "XSS", "SQL injection", "SSRF", "IDOR",
    "path traversal", "command injection",
    "XXE", "CSRF", "broken authentication",
    "security misconfiguration", "remote code execution",
    "SSTI", "open redirect", "deserialization"
]

OUTPUT_FILE = Path(__file__).parent.parent / "data" / "nvd" / "cves.json"


def fetch_cves(keyword: str, results_per_page: int = 10) -> list[dict]:
    params = {"keywordSearch": keyword, "resultsPerPage": results_per_page}
    try:
        resp = requests.get(NVD_BASE_URL, params=params, timeout=15)
        resp.raise_for_status()
        return resp.json().get("vulnerabilities", [])
    except Exception as e:
        print(f"  Error fetching '{keyword}': {e}")
        return []


def parse_cve(vuln: dict) -> dict | None:
    try:
        cve = vuln["cve"]
        cve_id = cve["id"]
        descriptions = cve.get("descriptions", [])
        description = next((d["value"] for d in descriptions if d.get("lang") == "en"), "")
        if not description:
            return None

        metrics = cve.get("metrics", {})
        cvss_score = None
        severity = "UNKNOWN"
        for version in ["cvssMetricV31", "cvssMetricV30", "cvssMetricV2"]:
            if version in metrics and metrics[version]:
                m = metrics[version][0]
                cvss_data = m.get("cvssData", {})
                cvss_score = cvss_data.get("baseScore")
                severity = m.get("baseSeverity") or cvss_data.get("baseSeverity", "UNKNOWN")
                break

        weaknesses = cve.get("weaknesses", [])
        cwe_ids = []
        for w in weaknesses:
            for desc in w.get("description", []):
                if desc.get("lang") == "en":
                    cwe_ids.append(desc["value"])

        return {
            "id": cve_id,
            "description": description,
            "cvss_score": cvss_score,
            "severity": severity,
            "cwe_ids": cwe_ids,
            "published": cve.get("published", "")[:10],
            "source": "NVD",
        }
    except Exception:
        return None


def main():
    all_cves = []
    seen_ids = set()

    for keyword in KEYWORDS:
        print(f"Fetching CVEs for: '{keyword}'")
        raw_vulns = fetch_cves(keyword, 10)
        for vuln in raw_vulns:
            parsed = parse_cve(vuln)
            if parsed and parsed["id"] not in seen_ids:
                seen_ids.add(parsed["id"])
                all_cves.append(parsed)
        time.sleep(0.7)

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_FILE, "w") as f:
        json.dump(all_cves, f, indent=2)

    print(f"\n✅ Saved {len(all_cves)} CVEs to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
