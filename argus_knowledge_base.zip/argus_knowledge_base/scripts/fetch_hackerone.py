#!/usr/bin/env python3
# scripts/fetch_hackerone.py
# Run this to refresh HackerOne disclosed reports
# Usage: python scripts/fetch_hackerone.py
# Output: data/hackerone/disclosed_reports.json

import json
import time
import requests
from pathlib import Path

OUTPUT_FILE = Path(__file__).parent.parent / "data" / "hackerone" / "disclosed_reports.json"

HEADERS = {"Content-Type": "application/json", "User-Agent": "Argus-Research/1.0"}

GRAPHQL_QUERY = """
query ArgusGetReports($cursor: String) {
  reports(
    first: 25
    after: $cursor
    order_by: { field: popular, direction: DESC }
    where: { disclosed_at: { _is_null: false } }
  ) {
    pageInfo { hasNextPage endCursor }
    edges {
      node {
        id title vulnerability_information disclosed_at
        severity { rating score }
        weakness { name external_id }
        structured_scope { asset_identifier }
        reporter { username }
      }
    }
  }
}
"""

# Fallback: well-known public report IDs if GraphQL fails
FALLBACK_IDS = [
    "1820801","1749014","1407728","1065041","759247",
    "534450","1353136","974607","425022","1236900",
    "904522","753567","468284","398799","341876",
    "1175273","1069487","819088","781172","977638",
    "1523090","1608653","1643644","983963","1347062",
]


def graphql_fetch(max_reports=100):
    reports, cursor, seen = [], None, set()
    while len(reports) < max_reports:
        variables = {"cursor": cursor} if cursor else {}
        try:
            resp = requests.post(
                "https://hackerone.com/graphql",
                json={"query": GRAPHQL_QUERY, "variables": variables},
                headers=HEADERS, timeout=20
            )
            resp.raise_for_status()
            data = resp.json().get("data", {})
            if not data or "reports" not in data:
                break
            for edge in data["reports"]["edges"]:
                node = edge["node"]
                vuln_info = node.get("vulnerability_information", "").strip()
                if vuln_info and len(vuln_info) > 50 and node["id"] not in seen:
                    seen.add(node["id"])
                    reports.append({
                        "id": node["id"],
                        "title": node.get("title", "").strip(),
                        "vuln_info": vuln_info[:3000],
                        "severity": (node.get("severity") or {}).get("rating", "unknown").upper(),
                        "weakness_name": (node.get("weakness") or {}).get("name", "Unknown"),
                        "weakness_cwe": (node.get("weakness") or {}).get("external_id", ""),
                        "asset": (node.get("structured_scope") or {}).get("asset_identifier", ""),
                        "disclosed_at": (node.get("disclosed_at") or "")[:10],
                        "url": f"https://hackerone.com/reports/{node['id']}",
                    })
            page_info = data["reports"]["pageInfo"]
            if not page_info.get("hasNextPage"):
                break
            cursor = page_info.get("endCursor")
            time.sleep(0.5)
        except Exception as e:
            print(f"  GraphQL error: {e}")
            break
    return reports


def fallback_fetch():
    reports = []
    for rid in FALLBACK_IDS:
        try:
            resp = requests.get(
                f"https://hackerone.com/reports/{rid}.json",
                headers=HEADERS, timeout=15
            )
            if resp.status_code == 200:
                data = resp.json()
                vuln_info = data.get("vulnerability_information", "").strip()
                if vuln_info and len(vuln_info) > 50:
                    reports.append({
                        "id": str(rid),
                        "title": data.get("title", "").strip(),
                        "vuln_info": vuln_info[:3000],
                        "severity": (data.get("severity") or {}).get("rating", "UNKNOWN").upper(),
                        "weakness_name": (data.get("weakness") or {}).get("name", "Unknown"),
                        "weakness_cwe": (data.get("weakness") or {}).get("external_id", ""),
                        "asset": "",
                        "disclosed_at": (data.get("disclosed_at") or "")[:10],
                        "url": f"https://hackerone.com/reports/{rid}",
                    })
                    print(f"  ✓ {rid}: {data.get('title','')[:60]}")
        except Exception as e:
            print(f"  ✗ {rid}: {e}")
        time.sleep(0.4)
    return reports


def main():
    print("Trying GraphQL API...")
    reports = graphql_fetch(max_reports=100)

    if not reports:
        print("GraphQL failed — using fallback public JSON endpoint...")
        reports = fallback_fetch()

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_FILE, "w") as f:
        json.dump(reports, f, indent=2)

    print(f"\n✅ Saved {len(reports)} HackerOne reports to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
